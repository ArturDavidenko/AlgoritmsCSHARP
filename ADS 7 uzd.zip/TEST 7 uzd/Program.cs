﻿using System;

namespace TEST_7_uzd
{
    class Program
    {
        static void Main(string[] args)
        {
            Tree tree = new Tree();

            while (true)
            {
                Console.WriteLine("Iespejamas darbibas:");
                Console.WriteLine("0 - beigt darbu");
                Console.WriteLine("1 - pievienot pamatrajonu");
                Console.WriteLine("2 - pievienot apaksrajonu");
                Console.WriteLine("3 - labot rajona datus");
                Console.WriteLine("4 - izvadit rajonu un apaksrajonu datus");

                int choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Ievadiet rajona nosaukumu:");
                        string districtName = Console.ReadLine();
                        Console.WriteLine("Ievadiet rajona platibu:");
                        int districtArea = Convert.ToInt32(Console.ReadLine());
                        tree.AddDistrict(districtName, districtArea);
                        break;

                    case 2:
                        Console.WriteLine("Ievadiet rajona nosaukumu, kuram pievienot:");
                        string parentDistrict = Console.ReadLine();
                        Console.WriteLine("Ievadiet apaksrajona nosaukumu:");
                        string subDistrictName = Console.ReadLine();
                        Console.WriteLine("Ievadiet apaksrajona platibu:");
                        int subDistrictArea = Convert.ToInt32(Console.ReadLine());
                        tree.AddSubDistrict(parentDistrict, subDistrictName, subDistrictArea);
                        break;

                    case 3:
                        Console.WriteLine("Ievadiet labojama rajona nosaukumu:");
                        string oldDistrictName = Console.ReadLine();
                        Console.WriteLine("Ievadiet jauno rajona nosaukumu:");
                        string newDistrictName = Console.ReadLine();
                        Console.WriteLine("Ievadiet jauno rajona platibu:");
                        int newDistrictArea = Convert.ToInt32(Console.ReadLine());
                        tree.UpdateDistrict(oldDistrictName, newDistrictName, newDistrictArea);
                        break;

                    case 4:
                        tree.PrintTree();
                        break;

                    case 0:
                        Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("Nepareiza izvele. Meginiet velreiz.");
                        break;
                }
            }

        }
    }
}
