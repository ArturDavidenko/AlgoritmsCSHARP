﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TEST_7_uzd
{
    class House
    {
        public Zars District { get; set; }
        public List<House> SubDistricts { get; set; }

        public House(Zars district)
        {
            District = district;
            SubDistricts = new List<House>();
        }

    }
}
