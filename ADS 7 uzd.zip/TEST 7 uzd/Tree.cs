﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TEST_7_uzd
{
    class Tree
    {
        public List<House> Houses { get; set; }

        public Tree()
        {
            Houses = new List<House>();
        }

        public void PrintTree()
        {
            foreach (var house in Houses)
            {
                PrintHouse(house, 0);
            }
        }

        private void PrintHouse(House house, int level)
        {
            string indentation = new string('-', level * 5);
            Console.WriteLine($"{indentation}{house.District.Name}({house.District.Area})");

            foreach (var subDistrict in house.SubDistricts)
            {
                PrintHouse(subDistrict, level + 1);
            }
        }

        public House FindDistrict(string districtName, House currentHouse = null)
        {
            if (currentHouse == null)
            {
                return Houses.Find(h => h.District.Name == districtName) ?? FindSubDistrict(districtName);
            }

            if (currentHouse.District.Name == districtName)
            {
                return currentHouse;
            }

            foreach (var subDistrict in currentHouse.SubDistricts)
            {
                var foundDistrict = FindDistrict(districtName, subDistrict);
                if (foundDistrict != null)
                {
                    return foundDistrict;
                }
            }

            return null;
        }

        private House FindSubDistrict(string districtName)
        {
            foreach (var house in Houses)
            {
                var foundSubDistrict = FindDistrict(districtName, house);
                if (foundSubDistrict != null)
                {
                    return foundSubDistrict;
                }
            }

            return null;
        }

        public void AddDistrict(string name, int area)
        {
            Zars district = new Zars(name, area);
            House newHouse = new House(district);
            Houses.Add(newHouse);
        }

        public void AddSubDistrict(string parentDistrictName, string subDistrictName, int subDistrictArea)
        {
            House parentHouse = FindDistrict(parentDistrictName);

            if (parentHouse != null)
            {
                Zars subDistrict = new Zars(subDistrictName, subDistrictArea);
                House newHouse = new House(subDistrict);
                parentHouse.SubDistricts.Add(newHouse);
            }
            else
            {
                Console.WriteLine("Rajons nav atrasts. Meginiet velreiz.");
            }
        }

        public void UpdateDistrict(string oldDistrictName, string newDistrictName, int newArea)
        {
            House houseToUpdate = FindDistrict(oldDistrictName);

            if (houseToUpdate != null)
            {
                houseToUpdate.District.Name = newDistrictName;
                houseToUpdate.District.Area = newArea;
            }
            else
            {
                Console.WriteLine("Rajons nav atrasts.");
            }
        }
    }
}
