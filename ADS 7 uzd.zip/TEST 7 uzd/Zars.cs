﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TEST_7_uzd
{
    class Zars
    {
        public string Name { get; set; }
        public int Area { get; set; }

        public Zars(string name, int area)
        {
            Name = name;
            Area = area;
        }

    }
}
